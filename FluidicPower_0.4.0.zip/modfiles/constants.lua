-- Here some global constants are stored
return {



    -- DEBUG OPTIONS 

    -- This will place the fluidbox above the electical entity
    -- Currently breaks the build mechanism.
    expose_fluid_boxes = false  
}